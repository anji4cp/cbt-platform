<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Super Admin - CBT</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <?php echo app('Illuminate\Foundation\Vite')('resources/css/app.css'); ?>
</head>
<body class="bg-slate-100">

<div class="flex min-h-screen">

    <!-- SIDEBAR -->
    <aside id="sidebar"
           class="w-64 bg-gradient-to-b from-slate-900 to-slate-800
                  text-slate-200 p-5 transition-all duration-300">

        <!-- HEADER -->
        <div class="flex items-center justify-between mb-6">
            <h2 id="sidebarTitle"
                class="text-sm font-semibold tracking-wide uppercase text-slate-300">
                Super Admin
            </h2>

            <!-- TOGGLE -->
            <button onclick="toggleSidebar()"
                    class="text-slate-300 hover:text-white text-lg">
                ☰
            </button>
        </div>

        <!-- MENU -->
        <nav class="space-y-1 text-sm">

            <a href="<?php echo e(url('/super-admin/dashboard')); ?>"
               class="flex items-center gap-3 px-3 py-2 rounded
               <?php echo e(request()->is('super-admin/dashboard*')
                    ? 'bg-indigo-600 text-white'
                    : 'hover:bg-slate-700'); ?>">
                <span>📊</span>
                <span class="menu-text">Dashboard</span>
            </a>

            <a href="<?php echo e(route('schools.index')); ?>"
               class="flex items-center gap-3 px-3 py-2 rounded
               <?php echo e(request()->is('super-admin/schools*')
                    ? 'bg-indigo-600 text-white'
                    : 'hover:bg-slate-700'); ?>">
                <span>🏫</span>
                <span class="menu-text">Manajemen Sekolah</span>
            </a>

            <a href="<?php echo e(route('super.monitoring')); ?>"
               class="flex items-center gap-3 px-3 py-2 rounded
               <?php echo e(request()->is('super-admin/monitoring*')
                    ? 'bg-indigo-600 text-white'
                    : 'hover:bg-slate-700'); ?>">
                <span>📡</span>
                <span class="menu-text">Monitoring</span>
            </a>

        </nav>

        <!-- LOGOUT -->
        <form method="POST" action="<?php echo e(route('logout')); ?>" class="mt-8">
            <?php echo csrf_field(); ?>
            <button
                class="flex items-center gap-3 w-full px-3 py-2 rounded
                       hover:bg-red-600 hover:text-white">
                <span>🚪</span>
                <span class="menu-text">Logout</span>
            </button>
        </form>
    </aside>

    <!-- CONTENT -->
    <main class="flex-1 p-6 transition-all duration-300">

        <!-- TOP BAR -->
        <div class="mb-6 bg-white rounded-xl shadow-sm p-4 flex justify-between items-center">
            <div class="text-sm text-gray-600">
                Login sebagai:
                <strong class="text-gray-800">
                    <?php echo e(auth()->user()->email); ?>

                </strong>
            </div>

            <div class="text-xs text-gray-400">
                Super Admin Panel
            </div>
        </div>

        <?php echo $__env->yieldContent('content'); ?>
    </main>

</div>

<!-- SIDEBAR TOGGLE SCRIPT -->
<script>
    let collapsed = false;

    function toggleSidebar() {
        const sidebar = document.getElementById('sidebar');
        const texts = document.querySelectorAll('.menu-text');
        const title = document.getElementById('sidebarTitle');

        collapsed = !collapsed;

        if (collapsed) {
            sidebar.classList.remove('w-64');
            sidebar.classList.add('w-20');
            title.classList.add('hidden');
            texts.forEach(t => t.classList.add('hidden'));
        } else {
            sidebar.classList.add('w-64');
            sidebar.classList.remove('w-20');
            title.classList.remove('hidden');
            texts.forEach(t => t.classList.remove('hidden'));
        }
    }
</script>

</body>
</html>
<?php /**PATH E:\My Project\cbt-platform\resources\views/layouts/super_admin.blade.php ENDPATH**/ ?>