

<?php $__env->startSection('content'); ?>
<div class="max-w-xl mx-auto bg-white rounded-xl shadow p-6">
    <h2 class="text-lg font-semibold mb-4">Edit Siswa</h2>

    <form method="POST" action="<?php echo e(route('students.update', $student)); ?>">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>

        <div class="mb-4">
            <label class="text-sm">Nama</label>
            <input name="name"
                   value="<?php echo e($student->name); ?>"
                   class="w-full border rounded px-3 py-2">
        </div>

        <div class="mb-4">
            <label class="text-sm">Kelas</label>
            <input name="class"
                   value="<?php echo e($student->class); ?>"
                   class="w-full border rounded px-3 py-2">
        </div>

        <div class="flex gap-3">
            <button class="bg-indigo-600 text-white px-4 py-2 rounded">
                Simpan
            </button>

            <a href="<?php echo e(route('students.index')); ?>"
               class="px-4 py-2 border rounded">
                Batal
            </a>
        </div>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.school_admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\My Project\cbt-platform\resources\views/school_admin/students/edit.blade.php ENDPATH**/ ?>