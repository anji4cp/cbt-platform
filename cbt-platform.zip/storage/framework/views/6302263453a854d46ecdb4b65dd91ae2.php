

<?php $__env->startSection('content'); ?>
<h1 class="text-xl font-semibold mb-6">Data Siswa</h1>
    <p class="text-sm text-slate-500 mt-2">
        Gunakan template resmi. Jangan ubah nama kolom.
    </p>
    <br>
<!-- ACTION BAR -->
<div class="flex flex-wrap gap-4 mb-6">
    <a href="<?php echo e(route('school.students.create')); ?>"
       class="bg-indigo-600 text-white px-4 py-2 rounded hover:bg-indigo-700">
        + Tambah Siswa
    </a>

    <form method="POST"
        action="<?php echo e(route('school.students.import')); ?>"
        enctype="multipart/form-data"
        class="flex items-center gap-2">
        <?php echo csrf_field(); ?>

        <input type="file"
            name="file"
            required
            class="text-sm border rounded px-2 py-1 bg-white">

        <button class="bg-slate-700 text-white px-4 py-2 rounded">
            Import Excel
        </button>
    </form>


    <a href="<?php echo e(asset('templates/template_import_siswa.xlsx')); ?>"
    class="bg-slate-600 text-white px-4 py-2 rounded hover:bg-slate-700"
    download>
        ⬇ Template Import Siswa
    </a>


    <!-- HAPUS PER KELAS -->
    <form method="POST"
          action="<?php echo e(route('school.students.deleteByClass')); ?>"
          onsubmit="return confirm('Yakin hapus semua siswa di kelas ini?')"
          class="flex items-center gap-2">
        <?php echo csrf_field(); ?>
        <button class="bg-orange-600 text-white px-4 py-2 rounded hover:bg-orange-700">
                    Hapus Siswa
        </button>
        <select name="class"
                required
                class="border rounded px-3 py-2 text-sm">
            <option value="">Pilih Kelas</option>
            <?php $__currentLoopData = $classes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $class): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($class); ?>"><?php echo e($class); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </form>

    <!-- HAPUS SEMUA -->
    <form method="POST"
          action="<?php echo e(route('school.students.deleteAll')); ?>"
          onsubmit="return confirm('⚠️ SEMUA siswa akan dihapus. Lanjutkan?')">
        <?php echo csrf_field(); ?>
        <?php echo method_field('DELETE'); ?>

        <button class="bg-red-600 text-white px-4 py-2 rounded hover:bg-red-700">
            Hapus Semua Siswa
        </button>
    </form>
</div>

<!-- TAB KELAS -->
<div class="flex gap-2 mb-4 overflow-x-auto">
    <a href="<?php echo e(route('school.students.index')); ?>"
       class="px-4 py-2 rounded-full text-sm border
       <?php echo e(empty($selectedClass)
            ? 'bg-indigo-600 text-white border-indigo-600'
            : 'bg-white text-slate-600 hover:bg-slate-100'); ?>">
        Semua
    </a>

    <?php $__currentLoopData = $classes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $class): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <a href="<?php echo e(route('school.students.index', ['class' => $class])); ?>"
           class="px-4 py-2 rounded-full text-sm border whitespace-nowrap
           <?php echo e($selectedClass === $class
                ? 'bg-indigo-600 text-white border-indigo-600'
                : 'bg-white text-slate-600 hover:bg-slate-100'); ?>">
            <?php echo e($class); ?>

        </a>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>



<?php if(session('import_success')): ?>
    <div class="bg-green-50 border border-green-200 rounded-xl p-4 mb-6">
        <h3 class="font-semibold text-green-700 mb-2">
            ✅ Import Berhasil (<?php echo e(count(session('import_success'))); ?> data)
        </h3>

        <div class="overflow-x-auto">
            <table class="text-sm w-full">
                <thead class="bg-green-100">
                    <tr>
                        <th class="px-3 py-2 text-left">Baris</th>
                        <th class="px-3 py-2 text-left">Nama</th>
                        <th class="px-3 py-2 text-left">Username</th>
                        <th class="px-3 py-2 text-left">Kelas</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = session('import_success'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr class="border-t">
                            <td class="px-3 py-2"><?php echo e($row['row']); ?></td>
                            <td class="px-3 py-2"><?php echo e($row['name']); ?></td>
                            <td class="px-3 py-2"><?php echo e($row['username']); ?></td>
                            <td class="px-3 py-2"><?php echo e($row['class']); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
<?php endif; ?>


<?php if(session('import_failed')): ?>
    <div class="bg-red-50 border border-red-200 rounded-xl p-4 mb-6">
        <h3 class="font-semibold text-red-700 mb-2">
            ❌ Gagal Import (<?php echo e(count(session('import_failed'))); ?> data)
        </h3>

        <table class="text-sm w-full">
            <thead class="bg-red-100">
                <tr>
                    <th class="px-3 py-2 text-left">Baris</th>
                    <th class="px-3 py-2 text-left">Alasan</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = session('import_failed'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="border-t">
                        <td class="px-3 py-2"><?php echo e($row['row']); ?></td>
                        <td class="px-3 py-2"><?php echo e($row['reason']); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
<?php endif; ?>

    <?php if(session('success')): ?>
        <div class="mb-4 rounded-lg bg-green-50 border border-green-200 p-4 text-sm text-green-700">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>

<!-- TABLE -->
<div class="bg-white rounded-xl shadow overflow-x-auto">
<table class="w-full text-sm">
    <thead class="bg-slate-100 text-slate-600">
        <tr>
            <th class="px-4 py-3 text-left">Nama</th>
            <th class="px-4 py-3 text-left">Username</th>
            <th class="px-4 py-3 text-left">Password</th>
            <th class="px-4 py-3 text-left">Kelas</th>
            <th class="px-4 py-3 text-center">Status</th>
            <th class="px-4 py-3 text-center">Aksi</th>
        </tr>
    </thead>
    <tbody>
        <?php $__empty_1 = true; $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <tr class="border-t hover:bg-slate-50">
            <td class="px-4 py-3"><?php echo e($student->name); ?></td>
            <td class="px-4 py-3"><?php echo e($student->username); ?></td>
            <td class="px-4 py-3"><?php echo e($student->exam_password ?? '-'); ?></td>
            <td class="px-4 py-3"><?php echo e($student->class); ?></td>

            <td class="px-4 py-3 text-center">
                <?php if($student->is_active): ?>
                    <span class="px-2 py-1 text-xs rounded bg-green-100 text-green-700">
                        Aktif
                    </span>
                <?php else: ?>
                    <span class="px-2 py-1 text-xs rounded bg-red-100 text-red-700">
                        Nonaktif
                    </span>
                <?php endif; ?>
            </td>

            <td class="px-4 py-3 text-center">
                <div class="flex justify-center gap-2">
                    <a href="<?php echo e(route('school.students.edit', $student)); ?>"
                       class="px-3 py-1 text-xs rounded bg-blue-100 text-blue-700 hover:bg-blue-200">
                        Edit
                    </a>

                    <form method="POST"
                          action="<?php echo e(route('school.students.toggle', $student)); ?>">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PATCH'); ?>
                        <button
                            class="px-3 py-1 text-xs rounded
                            <?php echo e($student->is_active
                                ? 'bg-yellow-100 text-yellow-700 hover:bg-yellow-200'
                                : 'bg-green-100 text-green-700 hover:bg-green-200'); ?>">
                            <?php echo e($student->is_active ? 'Nonaktifkan' : 'Aktifkan'); ?>

                        </button>
                    </form>

                    <form method="POST"
                          action="<?php echo e(route('school.students.destroy', $student)); ?>"
                          onsubmit="return confirm('Hapus siswa ini?')">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button
                            class="px-3 py-1 text-xs rounded bg-red-100 text-red-700 hover:bg-red-200">
                            Hapus
                        </button>
                    </form>
                </div>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <tr>
            <td colspan="5" class="text-center py-6 text-slate-400">
                Tidak ada data siswa
            </td>
        </tr>
        <?php endif; ?>
    </tbody>
</table>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.school_admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\My Project\cbt-platform\resources\views/school_admin/students/index.blade.php ENDPATH**/ ?>