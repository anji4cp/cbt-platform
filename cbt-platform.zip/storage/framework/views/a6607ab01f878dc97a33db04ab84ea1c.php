

<?php $__env->startSection('content'); ?>
<div class="max-w-3xl mx-auto bg-white rounded-2xl shadow p-6">
    <div class="flex items-center gap-4 mb-6">
        <?php if($school->logo): ?>
            <img src="<?php echo e(asset('storage/'.$school->logo)); ?>"
                 class="w-20 h-20 rounded-lg object-contain bg-gray-100">
        <?php else: ?>
            <div class="w-20 h-20 rounded-lg bg-gray-200 flex items-center justify-center">
                LOGO
            </div>
        <?php endif; ?>

        <div>
            <h2 class="text-xl font-semibold"><?php echo e($school->name); ?></h2>
            <p class="text-sm text-gray-500">Server ID: <?php echo e($school->school_id); ?></p>
        </div>
    </div>

    <div class="grid grid-cols-2 gap-4 text-sm">
        <div>
            <span class="text-gray-500">Status</span><br>
            <strong><?php echo e(strtoupper($school->status)); ?></strong>
        </div>

        <div>
            <span class="text-gray-500">Kontak</span><br>
            <strong><?php echo e($school->contact ?? '-'); ?></strong>
        </div>

        <div>
            <span class="text-gray-500">Warna Tema</span><br>
            <span class="inline-block px-3 py-1 rounded text-white"
                  style="background: <?php echo e($school->theme_color); ?>">
                <?php echo e($school->theme_color); ?>

            </span>
        </div>
    </div>

    <div class="mt-6 text-right">
        <a href="<?php echo e(route('school.profile.edit')); ?>"
           class="bg-indigo-600 text-white px-4 py-2 rounded-lg hover:bg-indigo-700">
            Edit Profil
        </a>
    </div>
    <hr class="my-8">

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.school_admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\My Project\cbt-platform\resources\views/school_admin/profile/index.blade.php ENDPATH**/ ?>