

<?php $__env->startSection('content'); ?>
<h2>Monitoring Global</h2>

<ul>
    <li>Total Sekolah: <strong><?php echo e($totalSchools); ?></strong></li>
    <li>Total Siswa: <strong><?php echo e($totalStudents); ?></strong></li>
    <li>Ujian Sedang Berlangsung: <strong><?php echo e($activeSessions); ?></strong></li>
</ul>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.super_admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\My Project\cbt-platform\resources\views/super_admin/monitoring.blade.php ENDPATH**/ ?>