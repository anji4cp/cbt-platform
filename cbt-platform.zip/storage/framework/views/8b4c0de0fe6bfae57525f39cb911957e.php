

<?php $__env->startSection('content'); ?>
<div class="flex justify-between items-center mb-6">
    <h1 class="text-2xl font-semibold text-gray-800">
        Daftar Sekolah
    </h1>

    <a href="<?php echo e(route('schools.create')); ?>"
       class="bg-indigo-600 hover:bg-indigo-700 text-white px-4 py-2 rounded-lg text-sm font-medium shadow">
        + Tambah Sekolah
    </a>
</div>

<?php if(session('success')): ?>
    <div class="mb-6 flex items-start gap-3 rounded-lg border border-green-200 bg-green-50 p-4 text-green-800">
        <div class="text-xl">✅</div>
        <div class="text-sm font-medium">
            <?php echo e(session('success')); ?>

        </div>
    </div>
<?php endif; ?>

<div class="bg-white rounded-xl shadow overflow-x-auto">
    <table class="w-full text-sm">
        <thead class="bg-slate-100 text-slate-600">
            <tr>
                <th class="px-4 py-3 text-left">Nama Sekolah</th>
                <th class="px-4 py-3 text-center">School ID</th>
                <th class="px-4 py-3 text-center">Email</th>
                <th class="px-4 py-3 text-center">Status</th>
                <th class="px-4 py-2">Expired at</th>
                <th class="px-4 py-3 text-center">Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $schools; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $school): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr class="border-t hover:bg-slate-50">
                <td class="px-4 py-3 font-medium text-gray-800">
                    <?php echo e($school->name); ?>

                </td>

                <td class="px-4 py-3 text-center font-mono text-indigo-600">
                    <?php echo e($school->school_id); ?>

                </td>

                <td class="px-4 py-3 text-center text-sm text-gray-700">
                    <?php if($school->admins->count()): ?>
                        <?php $__currentLoopData = $school->admins; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $admin): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="font-mono text-indigo-600">
                                <?php echo e($admin->email); ?>

                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>
                        <span class="text-gray-400 italic">Belum ada admin</span>
                    <?php endif; ?>
                </td>


                <td class="px-4 py-3 text-center">
                    <span class="px-2 py-1 rounded text-xs font-semibold
                        <?php echo e($school->status === 'active' ? 'bg-green-100 text-green-700' :
                           ($school->status === 'trial' ? 'bg-yellow-100 text-yellow-700' :
                           'bg-red-100 text-red-700')); ?>">
                        <?php echo e(strtoupper($school->status)); ?>

                    </span>
                </td>

                <td class="px-4 py-2 text-center text-sm">
                    <?php if($school->expired_at): ?>
                        <?php
                            $expiredDate = \Carbon\Carbon::parse($school->expired_at)->startOfDay();
                            $today       = now()->startOfDay();
                            $daysLeft    = $today->diffInDays($expiredDate, false);
                        ?>

                        <?php echo e($expiredDate->format('d/m/Y')); ?>


                        <div class="text-xs text-gray-400">
                            <?php if($daysLeft > 0): ?>
                                <?php echo e($daysLeft); ?> hari lagi
                            <?php elseif($daysLeft === 0): ?>
                                Hari ini
                            <?php else: ?>
                                Expired
                            <?php endif; ?>
                        </div>
                    <?php endif; ?>

                </td>

                <td class="px-4 py-2 text-center">
                    <div class="flex justify-center gap-2">

                        
                        <a href="<?php echo e(route('schools.edit', $school)); ?>"
                        class="px-3 py-1 text-xs rounded bg-blue-100 text-blue-700 hover:bg-blue-200">
                            Edit
                        </a>

                        
                        <a href="<?php echo e(route('schools.admin.create', $school)); ?>"
                        class="px-3 py-1 text-xs rounded bg-indigo-100 text-indigo-700 hover:bg-indigo-200">
                            Admin
                        </a>

                        
                        <form method="POST"
                            action="<?php echo e(route('schools.destroy', $school)); ?>"
                            onsubmit="return confirm('⚠️ Yakin hapus sekolah ini?\nSemua data akan TERHAPUS permanen!')">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>

                            <button
                                class="px-3 py-1 text-xs rounded bg-red-100 text-red-700 hover:bg-red-200">
                                Hapus
                            </button>
                        </form>

                    </div>
                </td>

            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr>
                <td colspan="4" class="text-center py-6 text-gray-400">
                    Belum ada data sekolah
                </td>
            </tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.super_admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\My Project\cbt-platform\resources\views/super_admin/schools/index.blade.php ENDPATH**/ ?>