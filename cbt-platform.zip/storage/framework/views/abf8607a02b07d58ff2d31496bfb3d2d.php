

<?php $__env->startSection('content'); ?>

<div class="max-w-2xl mx-auto mt-12">
    <div class="bg-white rounded-2xl shadow p-6">

        <h1 class="text-xl font-semibold mb-6 text-center">
            Edit Ujian
        </h1>

        <form method="POST" action="<?php echo e(route('school.exams.update', $exam)); ?>" class="space-y-4">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>

            <!-- MAPEL -->
            <div>
                <label class="block text-sm font-medium mb-1">Mata Pelajaran</label>
                <input name="subject" value="<?php echo e($exam->subject); ?>" required
                       class="w-full border rounded-lg px-3 py-2">
            </div>

            <!-- TOKEN -->
            <div>
                <label class="block text-sm font-medium mb-1">Token</label>
                <input name="token" value="<?php echo e($exam->token); ?>" required
                       class="w-full border rounded-lg px-3 py-2">
            </div>

            <!-- JUMLAH SOAL -->
            <div>
                <label class="block text-sm font-medium mb-1">Jumlah Soal</label>
                <input type="number" name="total_questions"
                       value="<?php echo e($exam->total_questions); ?>" required
                       class="w-full border rounded-lg px-3 py-2">
            </div>

            <!-- DURASI -->
            <div class="grid grid-cols-2 gap-4">
                <div>
                    <label class="block text-sm font-medium mb-1">Durasi</label>
                    <input type="number" name="duration_minutes"
                           value="<?php echo e($exam->duration_minutes); ?>" required
                           class="w-full border rounded-lg px-3 py-2">
                </div>
                <div>
                    <label class="block text-sm font-medium mb-1">Minimal Kirim</label>
                    <input type="number" name="min_submit_minutes"
                           value="<?php echo e($exam->min_submit_minutes); ?>" required
                           class="w-full border rounded-lg px-3 py-2">
                </div>
            </div>

            <!-- KELAS -->
            <div>
                <label class="block text-sm font-medium mb-2">Kelas Peserta</label>
                <div class="grid grid-cols-2 gap-2">
                    <?php $__currentLoopData = $classes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $class): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <label class="flex items-center gap-2 text-sm">
                            <input type="checkbox"
                                   name="classes[]"
                                   value="<?php echo e($class); ?>"
                                   <?php echo e(in_array($class, $selectedClasses) ? 'checked' : ''); ?>>
                            <?php echo e($class); ?>

                        </label>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>

            <!-- PAKET SOAL -->
            <div>
                <label class="block text-sm font-medium mb-2">Paket Soal</label>

                <?php $__currentLoopData = $packages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $pkg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="border rounded-lg p-4 mb-4">

                    <input type="hidden" name="packages[<?php echo e($i); ?>][code]"
                        value="<?php echo e($pkg->package_code); ?>">

                    <label class="text-sm">
                        Link Soal Paket <?php echo e($pkg->package_code); ?>

                    </label>
                    <input name="packages[<?php echo e($i); ?>][pdf_url]"
                        value="<?php echo e($pkg->pdf_url); ?>"
                        class="w-full border rounded px-3 py-2 mb-2">

                    <?php
                        $keys = is_array($pkg->answer_key)
                            ? $pkg->answer_key
                            : json_decode($pkg->answer_key, true);
                    ?>

                    <label class="text-sm">
                        Kunci Jawaban Paket <?php echo e($pkg->package_code); ?>

                    </label>
                    <textarea name="packages[<?php echo e($i); ?>][answer_key]"
                            rows="2"
                            class="w-full border rounded px-3 py-2"><?php echo e(implode(',', $keys ?? [])); ?></textarea>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

            <!-- OPSI -->
            <div class="flex items-center gap-2">
                <input type="checkbox" name="show_result" value="1"
                       <?php echo e($exam->show_score ? 'checked' : ''); ?>>
                <label class="text-sm">Tampilkan hasil ke siswa</label>
            </div>

            <!-- ACTION -->
            <div class="flex justify-center gap-4 pt-6">
                <button class="bg-indigo-600 text-white px-8 py-2 rounded-lg">
                    Update
                </button>
                <a href="<?php echo e(route('school.exams.index')); ?>"
                   class="px-8 py-2 rounded-lg border">
                    Batal
                </a>
            </div>

        </form>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.school_admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\My Project\cbt-platform\resources\views/school_admin/exams/edit.blade.php ENDPATH**/ ?>