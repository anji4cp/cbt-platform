

<?php $__env->startSection('content'); ?>
<h1 class="text-xl font-semibold mb-6 text-center">Cetak Kartu Ujian</h1>
<div class="flex justify-center">
<form method="POST"
      action="<?php echo e(route('school.exam-cards.print')); ?>"
      target="_blank"
      class="bg-white rounded-xl shadow p-6 w-full max-w-xl">
    <?php echo csrf_field(); ?>

    <div class="mb-4">
        <select name="class"
                required
                class="w-full border rounded px-3 py-2">
            <?php $__currentLoopData = $classes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $class): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($class); ?>"><?php echo e($class); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>

    <div class="mb-4">
        <label class="block text-sm mb-1">Judul Kartu</label>
        <input name="title"
               value="KARTU PESERTA UJIAN"
               class="w-full border rounded px-3 py-2">
    </div>

    <div class="mb-4">
        <label class="block text-sm mb-1">Kop Instansi</label>
        <input name="kop"
               value="DINAS PENDIDIKAN......"
               class="w-full border rounded px-3 py-2">
    </div>

    <div class="mb-4">
        <label class="block text-sm mb-1">Tanggal Kartu</label>
        <input type="date"
               name="card_date"
               value="<?php echo e(date('Y-m-d')); ?>"
               class="border rounded px-3 py-2 text-sm">
    </div>

    <div class="mb-4">
        <label class="flex items-center gap-2">
            <input type="checkbox" name="show_password" value="1">
            Tampilkan Password Siswa
        </label>
    </div>

    <hr class="my-4">

    <div class="mb-3">
        <label class="block text-sm">Jabatan Penandatangan</label>
        <input name="position"
               placeholder="Contoh : Kepala Sekolah"
               class="w-full border rounded px-3 py-2">
    </div>

    <div class="mb-3">
        <label class="block text-sm">Nama Penandatangan</label>
        <input name="sign_name"
               class="w-full border rounded px-3 py-2">
    </div>

    <div class="mb-4">
        <label class="block text-sm">NIP</label>
        <input name="nip"
               class="w-full border rounded px-3 py-2">
    </div>

    <button type="submit"
            class="bg-indigo-600 text-white px-5 py-2 rounded">
        Cetak Kartu
    </button>
</form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.school_admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\My Project\cbt-platform\resources\views/school_admin/exam_cards/index.blade.php ENDPATH**/ ?>