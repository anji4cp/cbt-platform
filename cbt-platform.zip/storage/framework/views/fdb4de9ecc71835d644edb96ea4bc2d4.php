

<?php $__env->startSection('content'); ?>

<h1 class="text-2xl font-semibold mb-6">Dashboard Super Admin</h1>


<div class="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">

    <div class="bg-white rounded-xl shadow p-5">
        <div class="text-sm text-gray-500">Total Sekolah</div>
        <div class="text-3xl font-bold text-indigo-600">
            <?php echo e($totalSchools); ?>

        </div>
    </div>

    <div class="bg-white rounded-xl shadow p-5">
        <div class="text-sm text-gray-500">Sekolah Aktif</div>
        <div class="text-3xl font-bold text-green-600">
            <?php echo e($activeSchools ?? 0); ?>

        </div>
    </div>

    <div class="bg-white rounded-xl shadow p-5">
        <div class="text-sm text-gray-500">Sekolah Trial</div>
        <div class="text-3xl font-bold text-yellow-500">
            <?php echo e($trialSchools ?? 0); ?>

        </div>
    </div>

    <div class="bg-white rounded-xl shadow p-5">
        <div class="text-sm text-gray-500">Sekolah Expired</div>
        <div class="text-3xl font-bold text-red-600">
            <?php echo e($expiredSchools ?? 0); ?>

        </div>
    </div>

</div>


<div class="bg-white rounded-xl shadow p-6">
    <h3 class="font-semibold mb-4">Sekolah Terbaru</h3>

    <table class="w-full text-sm">
        <thead class="bg-slate-100 text-slate-600">
            <tr>
                <th class="px-4 py-2 text-left">Nama Sekolah</th>
                <th class="px-4 py-2">Server ID</th>
                <th class="px-4 py-2">Status</th>
                <th class="px-4 py-2">Dibuat</th>
                <th class="px-4 py-2">Expired at</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $recentSchools ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $school): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr class="border-t">
                <td class="px-4 py-2"><?php echo e($school->name); ?></td>
                <td class="px-4 py-2 text-center font-mono">
                    <?php echo e($school->school_id); ?>

                </td>
                <td class="px-4 py-2 text-center">
                    <span class="px-2 py-1 rounded text-xs
                        <?php echo e($school->status === 'active' ? 'bg-green-100 text-green-700' :
                            ($school->status === 'trial' ? 'bg-yellow-100 text-yellow-700' :
                           'bg-red-100 text-red-700')); ?>">
                        <?php echo e(strtoupper($school->status)); ?>

                    </span>
                </td>
                <td class="px-4 py-2 text-center">
                    <?php echo e($school->created_at->format('d/m/Y')); ?>

                </td>
                <td class="px-4 py-2 text-center text-sm">
                    <?php if($school->expired_at): ?>
                        <?php
                            $expiredDate = \Carbon\Carbon::parse($school->expired_at)->startOfDay();
                            $today       = now()->startOfDay();
                            $daysLeft    = $today->diffInDays($expiredDate, false);
                        ?>

                        <?php echo e($expiredDate->format('d/m/Y')); ?>


                        <div class="text-xs text-gray-400">
                            <?php if($daysLeft > 0): ?>
                                <?php echo e($daysLeft); ?> hari lagi
                            <?php elseif($daysLeft === 0): ?>
                                Hari ini
                            <?php else: ?>
                                Expired
                            <?php endif; ?>
                        </div>
                    <?php endif; ?>

                </td>

            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr>
                <td colspan="4" class="text-center py-6 text-gray-400">
                    Belum ada data sekolah
                </td>
            </tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.super_admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\My Project\cbt-platform\resources\views/super_admin/dashboard.blade.php ENDPATH**/ ?>