

<?php $__env->startSection('content'); ?>
<h1 class="text-xl font-semibold mb-6">Manajemen Ujian</h1>

<div class="flex justify-between items-center mb-6">
    <a href="<?php echo e(route('school.exams.create')); ?>"
       class="bg-indigo-600 text-white px-4 py-2 rounded-lg hover:bg-indigo-700">
        + Buat Ujian
    </a>
</div>

<div class="bg-white rounded-xl shadow overflow-x-auto">

<table class="w-full text-sm">
    <thead class="bg-slate-100 text-slate-600">
        <tr>
            <th class="px-4 py-3 text-left">Mata Pelajaran</th>
            <th class="px-4 py-3 text-left">Token</th>
            <th class="px-4 py-3 text-center">Status</th>
            <th class="px-4 py-3 text-center">Aksi</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $exams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $exam): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr class="border-t hover:bg-slate-50">

            <td class="px-4 py-3">
                <?php echo e($exam->subject); ?>

            </td>

            <td class="px-4 py-3 font-mono">
                <?php echo e($exam->token); ?>

            </td>

            <td class="px-4 py-3 text-center">
                <?php if($exam->is_active): ?>
                    <span class="px-2 py-1 text-xs rounded bg-green-100 text-green-700">
                        Aktif
                    </span>
                <?php else: ?>
                    <span class="px-2 py-1 text-xs rounded bg-red-100 text-red-700">
                        Nonaktif
                    </span>
                <?php endif; ?>
            </td>

            <td class="px-4 py-3 text-center">
                <div class="flex justify-center gap-2 flex-wrap">

                    <!-- EDIT -->
                    <a href="<?php echo e(route('school.exams.edit', $exam)); ?>"
                       class="px-3 py-1 text-xs rounded bg-blue-100 text-blue-700 hover:bg-blue-200">
                        Edit
                    </a>

                    <!-- TOGGLE -->
                    <form method="POST"
                          action="<?php echo e(route('school.exams.toggle', $exam)); ?>">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PATCH'); ?>
                        <button
                            class="px-3 py-1 text-xs rounded
                            <?php echo e($exam->is_active
                                ? 'bg-yellow-100 text-yellow-700 hover:bg-yellow-200'
                                : 'bg-green-100 text-green-700 hover:bg-green-200'); ?>">
                            <?php echo e($exam->is_active ? 'Nonaktifkan' : 'Aktifkan'); ?>

                        </button>
                    </form>

                    <!-- HAPUS -->
                    <form method="POST"
                          action="<?php echo e(route('school.exams.destroy', $exam)); ?>"
                          onsubmit="return confirm('Hapus ujian ini?')">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button
                            class="px-3 py-1 text-xs rounded bg-red-100 text-red-700 hover:bg-red-200">
                            Hapus
                        </button>
                    </form>

                </div>
            </td>

        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.school_admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\My Project\cbt-platform\resources\views/school_admin/exams/index.blade.php ENDPATH**/ ?>