

<?php $__env->startSection('content'); ?>

<div style="
    background: linear-gradient(135deg, <?php echo e(auth()->user()->school->theme_color ?? '#2563eb'); ?>, #1e40af);
    color:#fff;
    padding:18px 22px;
    border-radius:16px;
    margin-bottom:24px;
    display:flex;
    align-items:stretch;
    gap:20px;
">

    
    <div style="
        width:80px;
        display:flex;
        align-items:center;
        justify-content:center;
    ">
        <?php if(auth()->user()->school->logo): ?>
            <img
                src="<?php echo e(asset('storage/' . auth()->user()->school->logo)); ?>"
                style="
                    width:64px;
                    height:64px;
                    object-fit:cover;
                    border-radius:14px;
                    background:#fff;
                    padding:6px;
                "
                alt="Logo Sekolah">
        <?php else: ?>
            <div style="
                width:64px;
                height:64px;
                border-radius:14px;
                background:rgba(255,255,255,.25);
                display:flex;
                align-items:center;
                justify-content:center;
                font-size:12px;
                font-weight:600;
            ">
                LOGO
            </div>
        <?php endif; ?>
    </div>

    
    <div style="flex:1">
        <div style="font-size:13px;opacity:.85">
            Server ID Sekolah
        </div>

        <div style="font-size:26px;font-weight:700;letter-spacing:1px">
            <?php echo e($serverId); ?>

        </div>

        <div style="font-size:12px;opacity:.8">
            Bagikan ke siswa untuk login pertama
        </div>
    </div>

    
    <div style="display:flex;align-items:center">
        <button
            onclick="navigator.clipboard.writeText('<?php echo e($serverId); ?>')"
            style="
                background:#fff;
                color:#1e40af;
                border:none;
                padding:12px 18px;
                border-radius:12px;
                font-weight:600;
                cursor:pointer;
                height:fit-content;
            ">
            Copy
        </button>
    </div>

</div>

<h2>Dashboard Admin Sekolah</h2>

<div style="display:grid; grid-template-columns:repeat(4,1fr); gap:15px; margin-bottom:30px">

    <div style="background:#fff; padding:15px; border-radius:8px">
        <h4>Total Siswa</h4>
        <strong><?php echo e($totalStudents); ?></strong>
    </div>

    <div style="background:#fff; padding:15px; border-radius:8px">
        <h4>Siswa Aktif</h4>
        <strong><?php echo e($activeStudents); ?></strong>
    </div>

    <div style="background:#fff; padding:15px; border-radius:8px">
        <h4>Total Ujian</h4>
        <strong><?php echo e($totalExams); ?></strong>
    </div>

    <div style="background:#fff; padding:15px; border-radius:8px">
        <h4>Ujian Aktif</h4>
        <strong><?php echo e($activeExams); ?></strong>
    </div>

</div>

<!-- <div style="background:#fff; padding:20px; border-radius:8px">
    <h3>Status Ujian</h3>

    <?php if($runningSessions > 0): ?>
        <p style="color:green">
            🟢 <?php echo e($runningSessions); ?> siswa sedang mengerjakan ujian
        </p>
    <?php else: ?>
        <p style="color:gray">
            ⚪ Tidak ada ujian yang sedang berlangsung
        </p>
    <?php endif; ?>
</div> -->

<h3 class="text-lg font-semibold mb-4">Monitoring Siswa</h3>

<div class="flex gap-2 flex-wrap mb-4">
    <a href="<?php echo e(route('school.dashboard')); ?>"
       class="px-4 py-1 rounded <?php echo e(!$selectedClass ? 'bg-indigo-600 text-white' : 'bg-gray-200'); ?>">
        Semua
    </a>

    <?php $__currentLoopData = $classes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $class): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <a href="<?php echo e(route('school.dashboard', ['class' => $class])); ?>"
           class="px-4 py-1 rounded
           <?php echo e($selectedClass === $class ? 'bg-indigo-600 text-white' : 'bg-gray-200'); ?>">
            <?php echo e($class); ?>

        </a>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>

<table class="w-full border bg-white rounded shadow">
    <thead class="bg-gray-100">
        <tr>
            <th class="p-2 border">Nama</th>
            <th class="p-2 border">Kelas</th>
            <th class="p-2 border">Status</th>
        </tr>
    </thead>
    <tbody>
        <?php $__empty_1 = true; $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr class="text-center">
                <td class="border p-2"><?php echo e($s['name']); ?></td>
                <td class="border p-2"><?php echo e($s['class']); ?></td>
                <td class="border p-2">
                    <?php if($s['status'] === 'Sedang Ujian'): ?>
                        <span class="px-3 py-1 bg-yellow-100 text-yellow-800 rounded">
                            Sedang Ujian
                        </span>
                    <?php elseif($s['status'] === 'Selesai'): ?>
                        <span class="px-3 py-1 bg-green-100 text-green-800 rounded">
                            Selesai
                        </span>
                    <?php else: ?>
                        <span class="px-3 py-1 bg-gray-100 text-gray-700 rounded">
                            Belum Ujian
                        </span>
                    <?php endif; ?>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr>
                <td colspan="3" class="p-4 text-center text-gray-500">
                    Tidak ada siswa
                </td>
            </tr>
        <?php endif; ?>
    </tbody>
</table>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.school_admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\My Project\cbt-platform\resources\views/school_admin/dashboard.blade.php ENDPATH**/ ?>