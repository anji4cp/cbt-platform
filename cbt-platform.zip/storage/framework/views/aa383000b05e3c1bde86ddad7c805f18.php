

<?php $__env->startSection('content'); ?>

<div class="bg-white rounded-xl shadow p-6">

    <h2 class="text-lg font-semibold mb-4">Laporan Nilai</h2>

    
    <form method="GET" class="flex gap-4 mb-4 flex-wrap">

        <select name="exam_id" class="border rounded px-3 py-2">
            <option value="">Semua Ujian</option>
            <?php $__currentLoopData = $exams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $exam): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($exam->id); ?>"
                    <?php echo e($examId == $exam->id ? 'selected' : ''); ?>>
                    <?php echo e($exam->subject); ?>

                </option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>

        <select name="class" class="border rounded px-3 py-2">
            <option value="">Semua Kelas</option>
            <?php $__currentLoopData = $classes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($c); ?>"
                    <?php echo e($class == $c ? 'selected' : ''); ?>>
                    <?php echo e($c); ?>

                </option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>

        <button class="bg-indigo-600 text-white px-4 py-2 rounded">
            Filter
        </button>

        <a href="<?php echo e(route('school.reports.export', request()->query())); ?>"
        class="bg-green-600 text-white px-4 py-2 rounded">
            Export Excel
        </a>
    </form>

    
    <div class="overflow-x-auto">
        <table class="w-full border-collapse">
            <thead class="bg-gray-100">
                <tr>
                    <th class="p-2 border">Nama</th>
                    <th class="p-2 border">Kelas</th>
                    <th class="p-2 border">Ujian</th>
                    <th class="p-2 border">Nilai</th>
                    <th class="p-2 border">Waktu</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $sessions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr class="text-center">
                    <td class="border p-2"><?php echo e($s->student->name); ?></td>
                    <td class="border p-2"><?php echo e($s->student->class); ?></td>
                    <td class="border p-2"><?php echo e($s->exam->subject); ?></td>
                    <td class="border p-2 font-semibold"><?php echo e($s->score); ?></td>
                    <td class="border p-2 text-sm">
                        <?php echo e($s->submitted_at->format('d-m-Y H:i')); ?>

                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="5" class="text-center p-4 text-gray-500">
                        Tidak ada data
                    </td>
                </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.school_admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\My Project\cbt-platform\resources\views/school_admin/reports/index.blade.php ENDPATH**/ ?>